import { cardLimit, DamageFeed, rechargeCardData } from "./feed.mjs";

let ID = "the-hurt-locker";
let locker;
let windowChanges = Promise.resolve();
let startedCombats = new Set();
let buttons = new Set();
let preferenceWrites = Promise.resolve();

function save(key, value) {
  preferenceWrites = preferenceWrites.then(() => game.settings.set(ID, key, value)).catch(error => {
    console.error("The Hurt Locker | Could not save preference", error);
  });
  return preferenceWrites;
}

function updateButtons() {
  for (let button of buttons) {
    if (!button.isConnected) { buttons.delete(button); continue; }
    button.setAttribute("aria-pressed", String(Boolean(locker?.rendered)));
  }
}

function addButton(app, element) {
  if (!game.user.isGM) return;
  let root = element instanceof HTMLElement ? element : element?.[0];
  let controls = root?.querySelector("#chat-controls .control-buttons")
    ?? document.querySelector("#chat-controls .control-buttons");
  if (!controls || controls.querySelector(".hurt-locker-toggle")) return;
  let button = document.createElement("button");
  button.type = "button";
  button.className = "ui-control icon fa-solid fa-vault hurt-locker-toggle";
  button.setAttribute("aria-label", "Toggle The Hurt Locker");
  button.setAttribute("title", "The Hurt Locker");
  button.addEventListener("click", () => void toggle());
  controls.append(button);
  buttons.add(button);
  updateButtons();
}

function markRechargeCard({ subject }, dialog, message) {
  if (subject?.actor?.type !== "npc" || message.create === false) return;
  let item = subject.item ?? subject;
  foundry.utils.setProperty(message, `data.flags.${ID}.rechargeItem`, item.name);
}

function renderRechargeCard(message, { itemName, success, total }) {
  let node = document.createElement("li");
  node.className = "hl-recharge";
  node.dataset.messageId = message.id;
  node.dataset.success = String(success);

  let name = document.createElement("strong");
  name.className = "hl-recharge-name";
  name.textContent = itemName;
  let outcome = document.createElement("span");
  outcome.className = "hl-recharge-outcome";
  outcome.textContent = success ? "Recharged" : "Did not recharge";
  let result = document.createElement("span");
  result.className = "hl-recharge-roll";
  result.textContent = `Roll ${total}`;
  node.append(name, outcome, result);
  return node;
}

class HurtLocker extends foundry.applications.api.ApplicationV2 {
  static DEFAULT_OPTIONS = {
    id: ID,
    classes: ["hurt-locker"],
    window: { title: "The Hurt Locker", icon: "fa-solid fa-vault", resizable: true, minimizable: true },
    position: { width: 440, height: 620 }
  };

  constructor(options = {}) {
    super(options);
    this.feed = new DamageFeed({
      source: () => game.messages.contents,
      isGM: () => game.user.isGM,
      limit: () => game.settings.get(ID, "cardLimit"),
      includeRecharge: () => game.settings.get(ID, "includeRecharge"),
      render: message => this.renderCard(message),
      commit: nodes => this.commitCards(nodes),
      error: (error, message) => {
        console.error(`The Hurt Locker | Could not render card ${message.id}`, error);
        let node = document.createElement("li");
        node.className = "hl-card-error";
        node.dataset.messageId = message.id;
        node.textContent = "This card could not be rendered. Check the original in chat.";
        return node;
      }
    });
    this.savePosition = foundry.utils.debounce(position => void save("position", position), 300);
  }

  _canRender() { return game.user.isGM; }

  async _renderHTML() {
    let shell = document.createElement("div");
    shell.className = "hl-shell";
    shell.innerHTML = `
      <header class="hl-banner">
        <div class="hl-insignia" aria-hidden="true"><i class="fa-solid fa-vault"></i></div>
        <div><div class="hl-eyebrow">GAME MASTER / DAMAGE CONTROL</div><h2>The Hurt Locker</h2></div>
        <span class="hl-badge">GM ONLY</span>
      </header>
      <div class="hl-toolbar">
        <span><span class="hl-status-dot" aria-hidden="true"></span> Latest cards</span>
        <label>Keep <select class="hl-limit" aria-label="Number of cards to keep">
          ${Array.from({ length: 8 }, (_, index) => `<option value="${index + 3}">${index + 3}</option>`).join("")}
        </select></label>
      </div>
      <div class="hl-scroll hl-at-top">
        <div class="hl-empty"><i class="fa-solid fa-shield-heart" aria-hidden="true"></i>
          <h3>All quiet. For now.</h3><p>New Midi-QOL GM damage cards will appear here.</p>
          <p>NPC recharge results will appear here when enabled in module settings.</p>
          <p class="hl-hint">Midi-QOL must be configured to create GM damage cards.</p>
        </div>
        <ol class="hl-cards themed theme-light" aria-label="Recent cards, newest first"></ol>
      </div>
      <footer class="hl-footer"><span class="hl-count">0 cards</span><span>NEWEST FIRST <span aria-hidden="true">↑</span></span></footer>`;
    let select = shell.querySelector(".hl-limit");
    select.value = String(cardLimit(game.settings.get(ID, "cardLimit")));
    select.addEventListener("change", () => void save("cardLimit", cardLimit(select.value)));
    let scroll = shell.querySelector(".hl-scroll");
    scroll.addEventListener("scroll", () => {
      scroll.classList.toggle("hl-at-top", scroll.scrollTop <= 2);
    }, { passive: true });
    return shell;
  }

  _replaceHTML(result, content) { content.replaceChildren(result); }

  _onRender() {
    this.feed.open();
    void save("open", true);
    updateButtons();
  }

  _onPosition(position) {
    if (!this.rendered || this.minimized) return;
    let { top, left, width, height } = position;
    if ([top, left, width, height].every(Number.isFinite)) this.savePosition({ top, left, width, height });
  }

  async close(options = {}) {
    this.feed.stop();
    await super.close(options);
    void save("open", false);
    updateButtons();
    return this;
  }

  async renderCard(message) {
    let recharge = rechargeCardData(message);
    if (recharge) return renderRechargeCard(message, recharge);
    let node = await foundry.applications.sidebar.tabs.ChatLog.renderMessage(message);
    node.classList.add("hl-card");
    let header = node.querySelector(":scope > .message-header");
    let timestamp = header?.querySelector(".message-timestamp");
    if (timestamp) header.before(timestamp);
    header?.remove();
    node.querySelector(".midi-qol-damage-card")?.classList.remove("collapsed");
    node.querySelectorAll(".message-delete, .message-dismiss").forEach(control => control.remove());
    return node;
  }

  commitCards(nodes) {
    let list = this.element?.querySelector(".hl-cards");
    if (!list) return;
    let scroll = this.element.querySelector(".hl-scroll");
    let atTop = scroll.scrollTop <= 2;
    scroll.classList.toggle("hl-at-top", atTop);
    let keep = new Set(nodes);
    for (let child of [...list.children]) if (!keep.has(child)) child.remove();
    for (let index = 0; index < nodes.length; index++) {
      if (list.children[index] !== nodes[index]) list.insertBefore(nodes[index], list.children[index] ?? null);
    }
    this.element.querySelector(".hl-empty").hidden = nodes.length > 0;
    this.element.querySelector(".hl-count").textContent = `${nodes.length} / ${cardLimit(game.settings.get(ID, "cardLimit"))} cards`;
    if (atTop) scroll.scrollTop = 0;
  }
}

function restoredPosition() {
  let saved = game.settings.get(ID, "position");
  let width = Math.min(Math.max(Number(saved.width) || 440, 340), window.innerWidth);
  let height = Math.min(Math.max(Number(saved.height) || 620, 300), window.innerHeight);
  let position = { width, height };
  if (Number.isFinite(saved.left)) position.left = Math.max(0, Math.min(saved.left, window.innerWidth - width));
  if (Number.isFinite(saved.top)) position.top = Math.max(0, Math.min(saved.top, window.innerHeight - height));
  return position;
}

function changeWindow(open) {
  windowChanges = windowChanges.then(async () => {
    if (!game.user.isGM) return;
    let show = open ?? !locker?.rendered;
    if (!show) {
      if (locker?.rendered) await locker.close();
      return;
    }
    locker ??= new HurtLocker({ position: restoredPosition() });
    if (!locker.rendered) await locker.render({ force: true, position: restoredPosition() });
    else if (locker.minimized) await locker.maximize();
  }).catch(error => {
    console.error("The Hurt Locker | Could not change window visibility", error);
    ui.notifications.error("The Hurt Locker could not update its window. See the console for details.");
  });
  return windowChanges;
}

function toggle() { return changeWindow(); }

function combatChanged(combat, deleted = false) {
  let wasStarted = startedCombats.has(combat.id);
  let isStarted = !deleted && combat.started;
  if (isStarted) startedCombats.add(combat.id);
  else startedCombats.delete(combat.id);
  if (!game.settings.get(ID, "autoCombat") || wasStarted === isStarted) return;
  if (isStarted) return changeWindow(true);
  if (!startedCombats.size) return changeWindow(false);
}

Hooks.once("init", () => {
  game.settings.register(ID, "autoCombat", {
    name: "Automatically open and close with combat",
    hint: "Open The Hurt Locker when combat starts and close it when the last running encounter ends or resets. Applies to this client only.",
    scope: "client", config: true, type: Boolean, default: true
  });
  game.settings.register(ID, "includeRecharge", {
    name: "Include NPC recharge cards",
    hint: "Show compact item and activity recharge results for NPC rolls that appear in chat. Applies to this client only.",
    scope: "client", config: true, type: Boolean, default: false,
    onChange: () => locker?.feed.reload()
  });
  game.settings.register(ID, "cardLimit", {
    name: "Cards to keep", hint: "Maximum damage and recharge cards in The Hurt Locker combined (3–10). Newest cards appear first.",
    scope: "client", config: true, type: Number, default: 5, range: { min: 3, max: 10, step: 1 },
    onChange: value => {
      let select = locker?.element?.querySelector(".hl-limit");
      if (select) select.value = String(cardLimit(value));
      locker?.feed.reload();
    }
  });
  game.settings.register(ID, "position", { scope: "client", config: false, type: Object, default: {} });
  game.settings.register(ID, "open", { scope: "client", config: false, type: Boolean, default: false });
  game.keybindings.register(ID, "toggle", {
    name: "Toggle The Hurt Locker", hint: "Show or close your GM card window.",
    editable: [{ key: "KeyH", modifiers: ["Alt"] }], restricted: true,
    onDown: () => { void toggle(); return true; }
  });
  Hooks.on("dnd5e.preRollRecharge", markRechargeCard);
});

Hooks.once("ready", () => {
  if (!game.user.isGM) return;
  if (!game.modules.get("midi-qol")?.active) {
    ui.notifications.warn("The Hurt Locker requires Midi-QOL to be enabled.");
    return;
  }
  game.modules.get(ID).api = Object.freeze({ toggle });
  startedCombats = new Set(game.combats.contents.filter(combat => combat.started).map(combat => combat.id));
  Hooks.on("createCombat", combat => combatChanged(combat));
  Hooks.on("updateCombat", combat => combatChanged(combat));
  Hooks.on("deleteCombat", combat => combatChanged(combat, true));
  Hooks.on("renderChatLog", addButton);
  Hooks.on("renderChatInput", addButton);
  Hooks.on("createChatMessage", message => locker?.feed.changed(message));
  Hooks.on("updateChatMessage", message => locker?.feed.changed(message));
  Hooks.on("deleteChatMessage", message => locker?.feed.changed(message, true));
  addButton(ui.chat, ui.chat?.element);
  if (game.settings.get(ID, "open")) void changeWindow(true);
});
