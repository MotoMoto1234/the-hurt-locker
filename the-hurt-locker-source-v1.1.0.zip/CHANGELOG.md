# Changelog

## 1.1.0

- Added an optional per-client setting to show compact NPC recharge results with the item name, outcome, and roll total.
- Reduced damage card height by replacing the header with a small timestamp and keeping the target rows expanded.

## 1.0.1

- Added a default-on, per-client setting to open the GM window when combat starts and close it when the last running encounter ends or resets.
- Observe confirmed combat changes on every GM client, including changes initiated by another GM.
- Preserve manual control during combat; ordinary turn and round changes do not reopen the window.
- Serialize window changes so combat ending during an in-progress opening still closes the window.

## 1.0 - First public release (1.0.0)

- GM-only damage-card window with chat toggle and rebindable Alt+H shortcut.
- Configurable 3-10 card limit, saved position and size, and open-state restoration.
- Bounded incremental rendering, grouped updates, and safe asynchronous close/update handling.
- Native Midi-QOL apply, undo, and multiplier controls.
- Stay at the top on arrivals and updates when already there, without forcing readers back from older cards.
- Compact 24-pixel sender avatars and normal title-bar minimization/restoration.
- Dark steel and brass framing without custom animation or blur.

Includes all fixes from local development builds 1.0.1-1.0.3. Public versioning starts at 1.0.0.
